'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, 'public');
const password = process.env.APP_PASSWORD;
const username = process.env.APP_USER || 'equipe';
if (!password || password.length < 12) { console.error('Configure APP_PASSWORD com pelo menos 12 caracteres.'); process.exit(1); }
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.webmanifest':'application/manifest+json; charset=utf-8','.png':'image/png'};
function equal(a,b){const aa=crypto.createHash('sha256').update(a).digest();const bb=crypto.createHash('sha256').update(b).digest();return crypto.timingSafeEqual(aa,bb);}
const server=http.createServer((req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
  res.setHeader('Cache-Control','private, no-store');
  const auth=req.headers.authorization||'';
  let ok=false;
  if(auth.startsWith('Basic ')){
    try { const decoded=Buffer.from(auth.slice(6),'base64').toString('utf8'); const sep=decoded.indexOf(':'); ok=sep>=0 && equal(decoded.slice(0,sep),username) && equal(decoded.slice(sep+1),password); }catch{}
  }
  if(!ok){res.writeHead(401,{'WWW-Authenticate':'Basic realm="Petkovic TV - Equipe", charset="UTF-8"','Content-Type':'text/plain; charset=utf-8'});return res.end('Acesso exclusivo da equipe Petkovic TV.');}
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);return res.end();}
  let pathname;
  try{pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);}catch{res.writeHead(400);return res.end();}
  const allowed = new Set(['/','/index.html','/ROLETAS_PETKOVIC_TV.html','/ROLETA_DO_TEMPO.html','/ROLETA_DE_ASSUNTOS.html','/manifest.webmanifest','/sw.js','/icons/icon-192.png','/icons/icon-512.png']);
  if(!allowed.has(pathname)){res.writeHead(404);return res.end('Nao encontrado');}
  const filename=path.join(root,pathname==='/'?'index.html':pathname.slice(1));
  fs.readFile(filename,(err,data)=>{if(err){res.writeHead(404);return res.end();}res.writeHead(200,{'Content-Type':mime[path.extname(filename)]||'application/octet-stream'});res.end(req.method==='HEAD'?undefined:data);});
});
server.listen(Number(process.env.PORT)||3000,'0.0.0.0',()=>console.log('Roletas Petkovic TV: servidor pronto'));
