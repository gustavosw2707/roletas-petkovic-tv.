// Sem cache de conteúdo protegido: autenticação validada no servidor em cada acesso.
self.addEventListener('install', event => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', event => { /* rede: nenhum cache privado */ });
